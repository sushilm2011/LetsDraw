package com.sushilmaurya.silentcoder.letsdraw;

/**
 * Created by silentcoder on 19/1/18.
 */

public class Constants {
    public static int SAVED = 1;
    public static int SHARED = 2;
    public static int PERMISSION_NOT_GRANTED = 3;
    public static int SAVE_FAILED = 4;
    public static int PERMISSION_ASKED = 5;
}
